function ubahText() {
    var element = document.getElementById('tombol')
    if (element.innerHTML == 'klik aku') {
        element.innerHTML = 'halo Yal'
    } else {
        element.innerHTML = 'klik aku'
    }
}